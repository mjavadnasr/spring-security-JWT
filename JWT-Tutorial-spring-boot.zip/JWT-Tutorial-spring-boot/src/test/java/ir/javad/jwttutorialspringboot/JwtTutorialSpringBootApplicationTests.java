package ir.javad.jwttutorialspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtTutorialSpringBootApplicationTests {

    @Test
    void contextLoads() {
    }

}
